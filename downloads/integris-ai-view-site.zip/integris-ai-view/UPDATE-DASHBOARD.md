# Updating your dashboard

This is the October 30, 2026 rescan package for msuddeth/integris-ai-dashboard.

## Publish this update

1. Unzip the package and open its integris-ai-view folder.
2. In your GitHub repository select Add file > Upload files.
3. Drag the contents of that folder, including every subfolder, into GitHub. Do not upload the outer folder or ZIP itself.
4. Commit to main with message: Update Integris review — October 30 rescan.
5. GitHub Pages republishes automatically. Follow progress under Actions.
6. Open https://msuddeth.github.io/integris-ai-dashboard/ and check the October 30 rescan date and 137 open findings.

The package adds a full-site ZIP download, restored build tools, a rescan summary and an item-level audit record. First Focus links open the original externally hosted report; it was not rescanned. Scores are explicitly historical.

## Future rescans

The build scripts format reports; they do not browse the company website, call an AI model, or automatically decide whether an issue is fixed.

Ask your assistant to recheck the current sources, preserve earlier closed items, update content/*.md, update site.json, add a dated change-log entry and save evidence in audit/. Confirm changes before uploading to GitHub.

To regenerate the existing design locally after editing the source reports:

```bash
python3 -m pip install -r requirements.txt
python3 scripts/build.py
python3 scripts/bundle.py
```

Compiled CSS is supplied. Recompiling Tailwind is unnecessary for report-text changes; it is needed only if new utility classes/design changes are introduced. tailwind.config.js and src/input.css are included for that purpose.

The downloadable ZIP now includes the build scripts and shared template. It does not contain itself recursively. The offline HTML download includes the whole report.

## Counting and evidence

One top-level issue bullet counts once. Any bullet containing a resolved checkmark is excluded; keep unresolved concerns on their own bullet. Audit corrections are separately recorded from verified resolutions. The summary and page badges are regenerated from the source bullets. The scorecard remains a separately maintained assessment and does not change automatically when issue counts change.

Do not mark browser-dependent functions broken merely because initial HTML lacks their fields. No form submissions were attempted in this rescan. No scheduled refresh, API key or external write was configured.
