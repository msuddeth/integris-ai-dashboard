#!/usr/bin/env python3
"""Package a built site for hand-off.

Usage:  python3 scripts/bundle.py [site]     (no argument = Integris at the repo root; "firstfocus" = First Focus)

Run after build.py and the Tailwind compile. Produces in <site>/downloads/:
  <name>.html      one self-contained file: overview, every page report and every extra page,
                   CSS inlined, every internal link pointing inside the file
  <name>-site.zip  the full static site plus the markdown sources
Links to the other company's report point to its published address.
"""
import pathlib
import re
import sys
import zipfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import build  # noqa: E402


def between(text, start, end):
    return text.split(start, 1)[1].split(end, 1)[0]


def strip_blocks(text, start, end):
    return re.sub(re.escape(start) + r".*?" + re.escape(end), "", text, flags=re.S)


def relink(text):
    text = re.sub(r'href="(?:\.\./)?index\.html#([a-z-]+)"', r'href="#\1"', text)
    text = re.sub(r'href="(?:\.\./)?index\.html"', 'href="#top"', text)
    text = re.sub(rf'href="(?:pages/)?({build.page_slugs()})\.html(#[a-z-]+)?"',
                  lambda m: f'href="{m.group(2) or "#" + m.group(1)}"', text)
    return text


def externalize(text, prefix):
    """Point links into the other company's report at its published address."""
    cmp_ = build.SITE["compare"]
    text = text.replace(f'href="{prefix}{cmp_["rel"]}"', f'href="{cmp_["abs"]}"')
    other_root = cmp_["rel"].rsplit("index.html", 1)[0]
    return re.sub(rf'href="{re.escape(prefix + other_root)}pages/([a-z0-9-]+\.html)(#[a-z-]+)?"',
                  lambda m: f'href="{cmp_["abs"]}pages/{m.group(1)}{m.group(2) or ""}"', text)


def section(path, prefix):
    body = between(path.read_text(), "<!--BUNDLE-START-->", "<!--BUNDLE-END-->")
    body = externalize(body, prefix)
    return body.replace("&larr; All pages", "&larr; Back to overview")


def single_file():
    S = build.SITE
    root = build.ROOT
    pages = build.load_pages()
    order = [n for _, _, nums in build.GROUPS for n in nums]
    css = (root / "assets" / "theme.css").read_text() + "\n" + (root / "assets" / "site.css").read_text()

    parts = [f'<div id="top">{section(root / "index.html", "")}</div>']
    extras = [("changelog", "brand-orange")] + [(t[1].removesuffix(".html"), "brand-purple") for t in S["templates"]]
    for slug, tone in extras:
        parts.append(f'<div id="{slug}" class="scroll-mt-20 border-t-8 border-{tone}">{section(root / "pages" / f"{slug}.html", "../")}</div>')
    for n in order:
        p = pages[n]
        body = strip_blocks(section(root / "pages" / f'{p["slug"]}.html', "../"), "<!--SIDEBAR-->", "<!--/SIDEBAR-->")
        body = body.replace("lg:grid lg:grid-cols-[240px_1fr] lg:gap-12", "max-w-5xl")
        parts.append(f'<div id="{p["slug"]}" class="scroll-mt-20 border-t-8 border-brand-plum">{body}</div>')

    items = [None if it is None else (it[0], re.sub(r"^(?:index\.html)?", "", it[1]) if it[1].startswith(("index.html#", "#")) else
             "#" + it[1].removeprefix("pages/").removesuffix(".html"))
             for it in build.nav_items("")]
    hdr = build.header_html("", items, "#" + S["example"]["href"].removeprefix("pages/").removesuffix(".html"),
                            S["example"]["label"], "", "#top", "", (S["compare"]["label"], S["compare"]["abs"]))
    doc = f"""<!doctype html>
<html lang="{S.get('lang', 'en')}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex, noai, noimageai">
<meta name="googlebot" content="noindex, nofollow">
<meta name="bingbot" content="noindex, nofollow">
<title>{build.esc(S['title_suffix'])} — How AI sees {build.esc(S['domain'])}</title>
<link href="{S['theme']['fonts_href']}" rel="stylesheet">
<style>
{css}
html {{ scroll-behavior: smooth; }}
</style>
</head>
<body class="bg-white font-sans text-brand-ink antialiased">
{hdr}
{"".join(parts)}
<footer class="mt-24 bg-brand-plum-deep text-white/80">
  <div class="mx-auto max-w-7xl px-4 py-10 text-sm sm:px-6 sm:flex sm:justify-between sm:gap-8">
    <p>{build.wordmark("text-lg", True)} {build.esc(S['product'])} &middot; Internal review of {build.esc(S['domain'])}</p>
    <p class="mt-3 sm:mt-0">Single-file edition. Original review {build.CAPTURED}. Flagged issues rechecked {build.esc(S.get("rescan_at", build.CAPTURED))}. Works offline; fonts load when online. <a class="font-semibold text-white hover:underline" href="{S['compare']['abs']}">{build.esc(S['compare']['label'])}</a></p>
  </div>
</footer>
</body>
</html>
"""
    doc = strip_blocks(relink(doc), "<!--DL-->", "<!--/DL-->")
    doc = re.sub(r"<!--/?(BUNDLE-START|BUNDLE-END|SIDEBAR)-->", "", doc)
    out = root / "downloads"
    out.mkdir(exist_ok=True)
    (out / S["downloads"]["html"]).write_text(doc)
    return doc


def site_zip():
    S, root = build.SITE, build.ROOT
    out = root / "downloads"
    target = out / S["downloads"]["zip"]
    folder = S["downloads"]["zip"].removesuffix("-site.zip")
    files = [root / "index.html", root / "site.json", out / S["downloads"]["html"]]
    if (root / "README.md").exists():
        files.append(root / "README.md")
    for extra in ("requirements.txt", "tailwind.config.js", ".nojekyll", "RESCAN-2026-10-30.md", "UPDATE-DASHBOARD.md", "ai-website-review-prompt.md"):
        if (root / extra).exists():
            files.append(root / extra)
    for sub in ("pages", "assets", "content", "src", "scripts", "shared", "audit"):
        if (root / sub).exists():
            files += sorted(p for p in (root / sub).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, pathlib.Path(folder) / f.relative_to(root))
    return target


if __name__ == "__main__":
    build.load_site(sys.argv[1] if len(sys.argv) > 1 else "")
    doc = single_file()
    z = site_zip()
    print(f"[{build.SITE['brand']}] single file: {len(doc)//1024} KB, zip: {z.stat().st_size//1024} KB")
