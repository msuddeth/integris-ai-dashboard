#!/usr/bin/env python3
"""Build an "AI View" report site from <site>/content/*.md and <site>/site.json.

Usage:
  python3 scripts/build.py              # Integris site (repo root)
  python3 scripts/build.py firstfocus   # First Focus site (firstfocus/)
Then compile CSS once for all sites and copy it to each site's assets/:
  ./tailwindcss -i src/input.css -o assets/site.css --minify && cp assets/site.css firstfocus/assets/
  python3 scripts/bundle.py [site]      # downloads/ for that site
"""
import html
import json
import pathlib
import re
import sys

import markdown

REPO = pathlib.Path(__file__).resolve().parent.parent
MD_EXT = ["tables", "sane_lists", "attr_list"]

# Set by load_site()
ROOT = CONTENT = PAGES = None
SITE = {}
GROUPS = []
CAPTURED = ""


def load_site(name=""):
    global ROOT, CONTENT, PAGES, SITE, GROUPS, CAPTURED
    ROOT = (REPO / name) if name else REPO
    CONTENT, PAGES = ROOT / "content", ROOT / "pages"
    SITE = json.loads((ROOT / "site.json").read_text())
    GROUPS = [tuple(g) for g in SITE["groups"]]
    CAPTURED = SITE["captured"]
    return SITE


def esc(s):
    return html.escape(s, quote=True)


def page_slugs():
    return "|".join([r"\d\d-[a-z0-9-]+", "changelog"] + [re.escape(t[1].removesuffix(".html")) for t in SITE["templates"]])


def link_md(out, prefix):
    return re.sub(rf'href="({page_slugs()})\.md"', rf'href="{prefix}\1.html"', out)


def load_pages():
    pages = {}
    for f in sorted(CONTENT.glob("[0-9][0-9]-*.md")):
        num = f.name[:2]
        if num == "00":
            continue
        text = f.read_text()
        title = re.search(r"^# (.+)$", text, re.M).group(1).replace(" — How AI reads this page", "").strip()
        url = re.search(r"\*\*URL:\*\*\s*(\S+)", text).group(1)
        block = text.split("## Issues the AI flagged", 1)
        issues = 0
        if len(block) == 2:
            issues = len([l for l in re.findall(r"^- .*$", block[1].split("\n## ")[0], re.M) if "✅" not in l])
        takeaway = ""
        m = re.search(r"## What the AI takes away\s+(.+?)(?:\n\n|\n##)", text, re.S)
        if m:
            takeaway = re.sub(r"\*\*|\[|\]\([^)]*\)", "", m.group(1)).strip().split("\n")[0].rstrip(":")
        pages[num] = dict(num=num, slug=f.stem, title=title, url=url, issues=issues, takeaway=takeaway, text=text)
    return pages


def render_body(text):
    body = re.sub(r"\A# .+?\n", "", text)
    body = re.sub(r"^\*\*(URL|Captured):\*\*.*\n", "", body, flags=re.M)
    out = link_md(markdown.markdown(body, extensions=MD_EXT), "")
    out = re.sub(r"~~(.*?)~~", r"<del>\1</del>", out, flags=re.S)
    return re.sub(r"(<h2>Issues the AI flagged</h2>.*?)(?=<h2>|\Z)", r'<section class="issues">\1</section>', out, flags=re.S)


def theme_css():
    t = SITE["theme"]
    vars_ = "".join(f"--brand-{k}:{v};" for k, v in t["colors"].items())
    return (f":root{{{vars_}--font-sans:{t['font_sans']};--font-display:{t['font_display']};"
            f"--radius-btn:{t['radius']};--hero-bg:{t['hero_bg']};}}")


def head(title, prefix):
    return f"""<!doctype html>
<html lang="{SITE.get('lang', 'en')}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex, noai, noimageai">
<meta name="googlebot" content="noindex, nofollow">
<meta name="bingbot" content="noindex, nofollow">
<title>{esc(title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="{SITE['theme']['fonts_href']}" rel="stylesheet">
<link rel="stylesheet" href="{prefix}assets/theme.css">
<link rel="stylesheet" href="{prefix}assets/site.css">
</head>
<body class="bg-white font-sans text-brand-ink antialiased">
"""


def nav_items(prefix):
    """site.json nav: ["Label", "#anchor"] -> index anchor, ["Label", "page:slug"] -> pages/slug.html, "|" -> separator."""
    items = []
    for it in SITE["nav"]:
        if it == "|":
            items.append(None)
            continue
        label, target = it
        if target.startswith("page:"):
            items.append((label, f"{prefix}pages/{target[5:]}.html"))
        elif target.startswith("compare:"):
            items.append((label, compare_href(prefix)))
        else:
            items.append((label, f"{prefix}index.html{target}"))
    return items


def wordmark(size="text-2xl", on_dark=False):
    w = SITE["wordmark"]
    return f'<span class="font-display {size} font-bold tracking-tight">{w["dark" if on_dark else "light"]}</span>'


def dl_names():
    d = SITE["downloads"]
    return d["html"], d["zip"]


def compare_href(prefix=""):
    target = SITE["compare"]["rel"]
    return target if target.startswith(("https://", "http://")) else prefix + target


def header(prefix):
    h, z = dl_names()
    ex = SITE["example"]
    return header_html(prefix, nav_items(prefix), prefix + ex["href"], ex["label"],
                       f'<!--DL--><a href="{prefix}downloads/{h}" download class="btn-primary whitespace-nowrap !px-4 !py-2 text-sm">&darr; <span class="hidden sm:inline">Download as </span>HTML</a><!--/DL-->',
                       f"{prefix}index.html",
                       f'<!--DL--><a href="{prefix}downloads/{h}" download class="drawer-link btn-primary w-full justify-center">&darr; Download as HTML</a><a href="{prefix}downloads/{z}" download class="drawer-link block text-center text-sm font-medium text-brand-gray hover:text-brand-accent">Download full site (.zip)</a><!--/DL-->',
                       (SITE["compare"]["label"], compare_href(prefix)))


def header_html(prefix, items, example_href, example_label, download_html, home_href, drawer_download="", compare=None):
    desktop = "".join('<span class="nav-sep" aria-hidden="true">|</span>' if it is None else
                      f'<a class="hover:text-brand-accent" href="{it[1]}">{esc(it[0])}</a>' for it in items)
    drawer_links = "".join('<div class="h-2 border-b border-gray-200 bg-brand-mist"></div>' if it is None else
                           f'<a class="drawer-link flex items-center justify-between border-b border-gray-100 px-6 py-4 text-lg font-medium hover:bg-brand-mist hover:text-brand-accent" href="{it[1]}">{esc(it[0])}<span aria-hidden="true" class="text-brand-gray">&rsaquo;</span></a>'
                           for it in items)
    compare_link = (f'<a href="{compare[1]}" class="drawer-link block rounded-btn border border-brand-plum/30 px-4 py-3 text-center text-sm font-semibold hover:border-brand-accent hover:text-brand-accent">{esc(compare[0])} &rarr;</a>'
                    if compare else "")
    product = esc(SITE["product"])
    return f"""<header class="sticky top-0 z-30 border-b border-gray-200 bg-white/95 backdrop-blur">
  <div class="mx-auto flex max-w-[1400px] items-center justify-between gap-4 whitespace-nowrap px-4 py-4 sm:px-6">
    <a href="{home_href}" class="flex items-baseline gap-2">
      {wordmark()}
      <span class="hidden text-sm font-medium text-brand-gray sm:inline">{product}</span>
    </a>
    <nav class="hidden items-center gap-4 text-sm font-medium nav:flex">{desktop}</nav>
    <div class="flex items-center gap-3">
      <a href="{example_href}" class="hidden rounded-btn border border-brand-purple px-4 py-2 text-sm font-medium text-brand-ink hover:bg-brand-purple hover:text-brand-on-purple lg:inline-flex nav:hidden">{esc(example_label)}</a>
      {download_html}
      <button type="button" id="menu-open" aria-controls="menu-drawer" aria-expanded="false" class="inline-flex items-center gap-2 rounded-btn border border-gray-300 px-3 py-2 text-sm font-medium hover:border-brand-purple nav:hidden">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>Menu
      </button>
    </div>
  </div>
</header>
<div id="menu-overlay" class="pointer-events-none fixed inset-0 z-40 bg-brand-plum-deep/50 opacity-0 transition-opacity duration-300"></div>
<aside id="menu-drawer" aria-label="Site menu" aria-hidden="true" class="invisible fixed inset-y-0 right-0 z-50 flex w-80 max-w-[85vw] translate-x-full flex-col bg-white shadow-2xl transition-transform duration-300 ease-out">
  <div class="flex items-center justify-between border-b-4 border-brand-red bg-brand-plum px-6 py-5 text-white">
    <span>{wordmark("text-xl", True)} <span class="text-sm font-medium text-white/70">{product}</span></span>
    <button type="button" id="menu-close" aria-label="Close menu" class="rounded-btn p-1 text-white/80 hover:bg-white/10 hover:text-white">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
    </button>
  </div>
  <nav class="flex-1 overflow-y-auto">{drawer_links}</nav>
  <div class="space-y-3 border-t border-gray-200 p-6">
    <a href="{example_href}" class="drawer-link btn-secondary w-full justify-center">{esc(example_label)}</a>
    {drawer_download}
    {compare_link}
  </div>
</aside>
<script>
(function () {{
  var d = document.getElementById('menu-drawer'), o = document.getElementById('menu-overlay'),
      b = document.getElementById('menu-open'), c = document.getElementById('menu-close');
  if (!d || !b) return;
  function set(open) {{
    d.classList.toggle('translate-x-full', !open); d.classList.toggle('invisible', !open);
    o.classList.toggle('opacity-0', !open); o.classList.toggle('pointer-events-none', !open);
    d.setAttribute('aria-hidden', String(!open)); b.setAttribute('aria-expanded', String(open));
    document.documentElement.classList.toggle('overflow-hidden', open);
    if (open) c.focus(); else b.focus({{preventScroll: true}});
  }}
  b.addEventListener('click', function () {{ set(true); }});
  c.addEventListener('click', function () {{ set(false); }});
  o.addEventListener('click', function () {{ set(false); }});
  document.addEventListener('keydown', function (e) {{ if (e.key === 'Escape' && b.getAttribute('aria-expanded') === 'true') set(false); }});
  d.querySelectorAll('.drawer-link').forEach(function (a) {{ a.addEventListener('click', function () {{ set(false); }}); }});
}})();
</script>
"""


def footer(prefix=""):
    h, z = dl_names()
    cmp_ = SITE["compare"]
    return f"""<footer class="mt-24 bg-brand-plum-deep text-white/80">
  <div class="mx-auto max-w-7xl px-4 py-10 text-sm sm:px-6 sm:flex sm:justify-between sm:gap-8">
    <p>{wordmark("text-lg", True)} {esc(SITE['product'])} &middot; Internal review of {esc(SITE['domain'])}</p>
    <p class="mt-3 sm:mt-0">Original review {CAPTURED}. Flagged issues rechecked {esc(SITE.get("rescan_at", CAPTURED))}. {esc(SITE['scope_note'])} <a class="font-semibold text-white hover:underline" href="{prefix}pages/changelog.html">Change log</a> &middot; <a class="font-semibold text-white hover:underline" href="{compare_href(prefix)}">{esc(cmp_['label'])}</a></p>
    <!--DL--><p class="mt-3 flex flex-wrap gap-4 sm:mt-0"><a class="font-semibold text-white hover:underline" href="{prefix}downloads/{h}" download>Download as HTML</a><a class="font-semibold text-white hover:underline" href="{prefix}downloads/{z}" download>Download full site (.zip)</a></p><!--/DL-->
  </div>
</footer>
</body>
</html>
"""


def hero(kicker, title, sub, extra="", size="page"):
    wm = SITE["theme"].get("watermark")
    wm_html = f'<span class="watermark" aria-hidden="true">{esc(wm)}</span>' if wm else ""
    if size == "index":
        return f"""<section class="hero-bg text-white">{wm_html}
  <div class="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
    <p class="text-sm font-semibold uppercase tracking-widest text-brand-orange">{kicker}</p>
    <h1 class="mt-4 max-w-4xl text-5xl font-extrabold leading-[1.02] sm:text-7xl">{title}</h1>
    <p class="mt-6 max-w-2xl text-xl text-white/85">{sub}</p>
    {extra}
  </div>
</section>"""
    return f"""<section class="hero-bg text-white">{wm_html}
  <div class="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16">
    <a href="../index.html" class="text-sm text-white/70 hover:text-white">&larr; All pages</a>
    <h1 class="mt-4 text-4xl font-bold leading-[1.05] sm:text-5xl">{title}</h1>
    <p class="mt-3 text-lg text-white/85">{sub}</p>
    {extra}
  </div>
</section>"""


def issue_badge(n):
    if n == 0:
        return ""
    tone = "bg-brand-red text-brand-on-red" if n >= 7 else "bg-brand-red/10 text-brand-accent"
    return f'<span class="shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold {tone}">{n} issues</span>'


def sidebar(pages, current):
    parts = []
    for gid, name, nums in GROUPS:
        items = []
        for n in nums:
            p = pages[n]
            cls = ("bg-brand-mist font-semibold text-brand-accent border-brand-red" if n == current
                   else "text-brand-ink border-transparent hover:text-brand-accent")
            items.append(f'<li><a class="block border-l-2 py-1.5 pl-3 {cls}" href="{p["slug"]}.html">{esc(p["title"])}</a></li>')
        parts.append(f'<div class="mb-6"><p class="mb-2 text-xs font-semibold uppercase tracking-wider text-brand-gray">{esc(name)}</p><ul class="text-sm">{"".join(items)}</ul></div>')
    return "".join(parts)


def build_page(pages, order, p):
    i = order.index(p["num"])
    prev_p = pages[order[i - 1]] if i > 0 else None
    next_p = pages[order[i + 1]] if i < len(order) - 1 else None
    nav = '<div class="mt-16 grid gap-4 sm:grid-cols-2">'
    nav += (f'<a href="{prev_p["slug"]}.html" class="rounded-lg border border-gray-200 p-4 hover:border-brand-purple"><span class="text-xs text-brand-gray">&larr; Previous</span><span class="block font-semibold">{esc(prev_p["title"])}</span></a>'
            if prev_p else "<span></span>")
    if next_p:
        nav += f'<a href="{next_p["slug"]}.html" class="rounded-lg border border-gray-200 p-4 text-right hover:border-brand-purple"><span class="text-xs text-brand-gray">Next &rarr;</span><span class="block font-semibold">{esc(next_p["title"])}</span></a>'
    nav += "</div>"
    side = sidebar(pages, p["num"])
    badges = f"""<div class="mt-6 flex flex-wrap items-center gap-3 text-sm">
      <a href="{esc(p["url"])}" target="_blank" rel="noopener" class="btn-primary">View live page &nearr;</a>
      <span class="rounded-btn border border-white/30 px-3 py-2 text-white/85">Original capture {CAPTURED}</span>
      <span class="rounded-btn border border-white/30 px-3 py-2 text-white/85">Rescanned {esc(SITE.get("rescan_at", CAPTURED))}</span>
      {'<span class="rounded-btn bg-white/10 px-3 py-2">' + str(p["issues"]) + ' issues flagged</span>' if p["issues"] else ''}
    </div>"""
    page_html = (
        head(f'{p["title"]} — {SITE["title_suffix"]}', "../") + header("../")
        + "<!--BUNDLE-START-->" + hero("", esc(p["title"]), "How AI reads this page", badges)
        + f"""
<div class="mx-auto max-w-7xl px-4 sm:px-6 lg:grid lg:grid-cols-[240px_1fr] lg:gap-12">
  <!--SIDEBAR--><aside class="hidden lg:block"><div class="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto py-10">{side}</div></aside>
  <main class="min-w-0 py-10">
    <details class="mb-8 rounded-lg border border-gray-200 lg:hidden"><summary class="cursor-pointer px-4 py-3 font-semibold">All pages</summary><div class="px-4 pb-2">{side}</div></details><!--/SIDEBAR-->
    <article class="report prose prose-brand max-w-none prose-headings:font-display prose-a:no-underline hover:prose-a:underline">
{render_body(p["text"])}
    </article>
    {nav}
  </main>
</div>
<!--BUNDLE-END-->""" + footer("../"))
    (PAGES / f'{p["slug"]}.html').write_text(page_html)


def build_index(pages):
    readme = (CONTENT / "00-README-summary.md").read_text()
    intro = readme.split("## How this was done", 1)[1].split("## The overall picture", 1)[0]
    picture = readme.split("## The overall picture", 1)[1].split("## Highest-priority fixes", 1)[0]
    fixes = readme.split("## Highest-priority fixes", 1)[1].split("## Recurring patterns", 1)[0]
    patterns = readme.split("## Recurring patterns", 1)[1].split("## Index", 1)[0]

    def md(s):
        return re.sub(r"~~(.*?)~~", r"<del>\1</del>", link_md(markdown.markdown(s, extensions=MD_EXT), "pages/"), flags=re.S)

    def link_nums(m):
        cells = [f"[{pages[n]['title']}](pages/{pages[n]['slug']}.html)" for n in re.findall(r"\d\d", m.group(1)) if n in pages]
        return "| " + ", ".join(cells) + (" (+ others)" if "+" in m.group(1) else "") + " |"
    fixes = re.sub(r"\| ([\d, +a-z]+?) \|\s*$", link_nums, fixes, flags=re.M)

    values = {"pages": len(pages), "issues": sum(p["issues"] for p in pages.values()),
              "open_fixes": len([l for l in fixes.split("\n") if re.match(r"\| \d+ \|", l) and "✅" not in l])}
    stat_html = "".join(
        f'<div class="{s.get("cls", "")}"><p class="font-display text-4xl font-bold text-brand-{s["color"]}">{str(s["value"]).format(**values)}</p><p class="text-sm text-brand-gray">{esc(s["label"])}</p></div>'
        for s in SITE["stats"])
    callout = SITE["callout"]
    promos = "".join(f"""<section class="mt-6 flex flex-col gap-6 rounded-2xl border border-brand-{p['tone']}/30 bg-{'brand-mist' if p['tone'] == 'purple' else 'white'} p-8 shadow-sm md:flex-row md:items-center md:justify-between">
    <div class="max-w-3xl">
      <p class="text-sm font-semibold uppercase tracking-widest text-brand-accent">{esc(p['kicker'])}</p>
      <h2 class="mt-2 text-3xl font-bold">{esc(p['title'])}</h2>
      <p class="mt-3 text-gray-700">{esc(p['text'])}</p>
    </div>
    <a href="{p['href']}" class="{'btn-secondary' if p['tone'] == 'purple' else 'btn-primary'} shrink-0">{esc(p['label'])} &rarr;</a>
  </section>""" for p in SITE["promos"])

    cards = []
    for gid, name, nums in GROUPS:
        items = "".join(f"""<a href="pages/{p['slug']}.html" class="group flex min-w-0 flex-col rounded-xl border border-gray-200 bg-white p-5 transition hover:-translate-y-0.5 hover:border-brand-purple hover:shadow-lg">
  <div class="flex items-start justify-between gap-3">
    <h3 class="text-lg font-semibold leading-snug group-hover:text-brand-accent">{esc(p['title'])}</h3>
    {issue_badge(p['issues'])}
  </div>
  <p class="mt-1 truncate text-xs text-brand-gray">{esc(p['url'].replace('https://', ''))}</p>
  <p class="mt-3 line-clamp-3 text-sm text-gray-700">{esc(p['takeaway'])}</p>
  <span class="mt-auto pt-4 text-sm font-medium text-brand-accent">Read the AI's view &rarr;</span>
</a>""" for p in (pages[n] for n in nums))
        cards.append(f"""<section id="{gid}" class="scroll-mt-24 pt-14">
  <h2 class="text-3xl font-bold">{esc(name)}</h2>
  <div class="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{items}</div>
</section>""")

    h, z = dl_names()
    cmp_ = SITE["compare"]
    hero_buttons = f"""<div class="mt-8 flex flex-wrap gap-3">
      <a href="#findings" class="btn-primary">See the key findings</a>
      <a href="{SITE['example']['href']}" class="btn-secondary">{esc(SITE['example']['label'])}</a>
      <a href="{cmp_['rel']}" class="inline-flex items-center gap-2 rounded-btn border border-white/60 bg-white/10 px-5 py-3 font-semibold text-white hover:bg-white/20">{esc(cmp_['label'])} &rarr;</a>
      <a href="#{GROUPS[0][0]}" class="inline-flex items-center gap-2 rounded-btn border border-white/40 px-5 py-3 text-white hover:bg-white/10">Browse all {len(pages)} pages</a>
      <!--DL--><a href="downloads/{z}" download class="inline-flex items-center gap-2 rounded-btn border border-white/40 px-5 py-3 text-white hover:bg-white/10">&darr; Download full site (.zip)</a><!--/DL-->
    </div>"""
    score = SITE["score"]
    index_html = (
        head(f"{SITE['title_suffix']} — How AI sees {SITE['domain']}", "") + header("")
        + "<!--BUNDLE-START-->"
        + hero(f"Rescanned &middot; {esc(SITE.get('rescan_at', CAPTURED))}", f"How AI sees {esc(SITE['domain'])}.", esc(SITE["hero_sub"]), hero_buttons, "index")
        + f"""
<section class="bg-brand-mist">
  <div class="mx-auto max-w-7xl px-4 py-12 sm:px-6">
    <h2 class="text-3xl font-bold sm:text-4xl">Some key findings</h2>
    <div class="mt-6 overflow-hidden rounded-2xl border border-gray-200 border-l-8 border-l-brand-red bg-white shadow-lg">
      <div class="grid grid-cols-2 gap-6 p-6 sm:p-8 md:grid-cols-{len(SITE['stats'])}">{stat_html}</div>
      <a href="{callout['href']}" class="flex items-center justify-between gap-4 bg-brand-red px-6 py-4 font-semibold text-brand-on-red hover:bg-brand-red-dark sm:px-8">
        <span>{esc(callout['text'])}</span><span aria-hidden="true">&rarr;</span>
      </a>
    </div>
    <a href="pages/scorecard.html" class="mt-6 flex flex-col gap-4 rounded-2xl bg-brand-plum p-6 text-white hover:bg-brand-plum-deep sm:flex-row sm:items-center sm:justify-between sm:p-8">
      <div class="flex items-center gap-5">
        <p class="font-display text-5xl font-bold">{score['this']}<span class="text-2xl text-white/60">/100</span></p>
        <div><p class="font-semibold">AI-readiness score</p><p class="text-sm text-white/75">{esc(score['blurb'])}</p></div>
      </div>
      <span class="font-semibold text-brand-orange">See how {esc(score['other_name'])} compares ({score['other']}/100) &rarr;</span>
    </a>
  </div>
</section>

<main class="mx-auto max-w-7xl px-4 sm:px-6">
  {promos}
  <section id="findings" class="scroll-mt-24 pt-16 lg:grid lg:grid-cols-[1fr_1fr] lg:gap-14">
    <div>
      <h2 class="text-4xl font-bold">The overall picture</h2>
      <div class="report prose prose-brand mt-6 max-w-none">{md(picture)}</div>
    </div>
    <div class="mt-12 lg:mt-0">
      <div class="rounded-2xl bg-brand-plum p-8 text-white">
        <h2 class="text-2xl font-bold">How this was done</h2>
        <div class="prose prose-invert mt-4 max-w-none text-white/85">{md(intro)}</div>
      </div>
    </div>
  </section>
  <section class="pt-16">
    <h2 class="text-4xl font-bold">Highest-priority fixes</h2>
    <div class="report prose prose-brand mt-6 max-w-none">{md(fixes)}</div>
  </section>
  <section class="pt-16">
    <h2 class="text-4xl font-bold">Recurring patterns</h2>
    <div class="report prose prose-brand mt-6 max-w-none">{md(patterns)}</div>
  </section>
  {''.join(cards)}
</main>
<!--BUNDLE-END-->""" + footer())
    (ROOT / "index.html").write_text(index_html)


def build_changelog():
    text = (CONTENT / "changelog.md").read_text()
    body = link_md(markdown.markdown(re.sub(r"\A# .+?\n", "", text), extensions=MD_EXT), "")
    latest = re.search(r"^## (.+)$", text, re.M).group(1)
    extra = f'<p class="mt-6 inline-block rounded-btn bg-white/10 px-3 py-2 text-sm">Latest: {esc(latest)}</p>'
    page_html = (
        head(f"Change log — {SITE['title_suffix']}", "../") + header("../")
        + "<!--BUNDLE-START-->" + hero("", "Change log", f"Rescans of {esc(SITE['domain'])} and updates to this report, newest first.", extra)
        + f"""
<main class="mx-auto max-w-4xl px-4 py-10 sm:px-6">
  <article class="report changelog prose prose-brand max-w-none prose-headings:font-display prose-a:no-underline hover:prose-a:underline">
{body}
  </article>
</main>
<!--BUNDLE-END-->""" + footer("../"))
    (PAGES / "changelog.html").write_text(page_html)


def build_template(src, out, title):
    path = ROOT / "src" / src
    if not path.exists():
        path = REPO / "shared" / src
    body = re.sub(r"\A<!--.*?-->\s*", "", path.read_text(), flags=re.S)
    cmp_ = SITE["compare"]
    body = (body.replace("%%COMPARE_HREF%%", compare_href("../")).replace("%%COMPARE_LABEL%%", esc(cmp_["label"]))
                .replace("%%THIS%%", esc(SITE["brand"])).replace("%%OTHER%%", esc(SITE["score"]["other_name"])))
    page_html = (head(f"{title} — {SITE['title_suffix']}", "../") + header("../")
                 + "<!--BUNDLE-START-->" + body + "<!--BUNDLE-END-->" + footer("../"))
    (PAGES / out).write_text(page_html)


def main():
    load_site(sys.argv[1] if len(sys.argv) > 1 else "")
    PAGES.mkdir(exist_ok=True)
    (ROOT / "assets").mkdir(exist_ok=True)
    (ROOT / "assets" / "theme.css").write_text(theme_css())
    pages = load_pages()
    order = [n for _, _, nums in GROUPS for n in nums]
    missing = [n for n in order if n not in pages]
    assert not missing, f"groups reference missing pages: {missing}"
    for n in order:
        build_page(pages, order, pages[n])
    build_index(pages)
    build_changelog()
    for src, out, title in SITE["templates"]:
        build_template(src, out, title)
    print(f"[{SITE['brand']}] built index + {len(order)} pages + {len(SITE['templates'])} templates")


if __name__ == "__main__":
    main()
