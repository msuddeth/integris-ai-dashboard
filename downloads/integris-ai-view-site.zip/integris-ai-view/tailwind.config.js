/** AI View — shared Tailwind config for every report site in this repo.
 *
 * Colours and fonts are CSS variables, so one compiled stylesheet serves every
 * brand; each site's assets/theme.css sets the values (see scripts/build.py and
 * each site's site.json).
 *
 *   Integris (sampled from integrisit.com):  red #CE0019 · purple #532C99 · plum #3A2742 · orange #F18614
 *   First Focus (sampled from firstfocus.com.au): orange #FF9E18 · cyan #00AEEF · charcoal #2B2B2B
 */
const v = (name) => `rgb(var(--brand-${name}) / <alpha-value>)`;

module.exports = {
  content: ['./index.html', './pages/**/*.html', './scripts/*.py', './src/*.html', './shared/*.html',
            './firstfocus/index.html', './firstfocus/pages/**/*.html', './firstfocus/src/*.html'],
  theme: {
    extend: {
      screens: { nav: '1440px' },
      colors: {
        brand: {
          red: v('red'), 'red-dark': v('red-dark'), 'on-red': v('on-red'),
          accent: v('accent'),
          purple: v('purple'), 'purple-dark': v('purple-dark'), 'on-purple': v('on-purple'),
          plum: v('plum'), 'plum-deep': v('plum-deep'),
          orange: v('orange'), gray: v('gray'), ink: v('ink'), mist: v('mist'),
        },
      },
      fontFamily: {
        sans: ['var(--font-sans)', 'Helvetica Neue', 'Arial', 'sans-serif'],
        display: ['var(--font-display)', 'Helvetica Neue', 'Arial', 'sans-serif'],
      },
      borderRadius: { btn: 'var(--radius-btn)' },
      typography: () => ({
        brand: {
          css: {
            '--tw-prose-body': 'rgb(var(--brand-ink))',
            '--tw-prose-headings': 'rgb(var(--brand-ink))',
            '--tw-prose-links': 'rgb(var(--brand-accent))',
            '--tw-prose-bold': 'rgb(var(--brand-ink))',
            '--tw-prose-bullets': 'rgb(var(--brand-red))',
            '--tw-prose-quote-borders': 'rgb(var(--brand-purple))',
            '--tw-prose-th-borders': 'rgb(var(--brand-plum))',
          },
        },
      }),
    },
  },
  plugins: [require('@tailwindcss/typography')],
};
